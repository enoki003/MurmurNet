class DispatcherAgent:
    """入力を分類し、適切な応答戦略を決定するエージェント"""

    def __init__(self, llm):
        self.llm = llm

    async def classify_input(self, input_text):
        """入力の種類を分類する"""
        prompt = f"以下の入力を分類してください。カテゴリは「挨拶」「質問」「指示」「会話」のいずれかです。\n\n入力: {input_text}\n\nカテゴリ:"
        messages = [{"role": "user", "content": prompt}]
        response = await self.llm.create_chat_completion(messages=messages, max_tokens=10)
        category = response["choices"][0]["message"]["content"].strip().lower()
        return category

    async def decide_response_strategy(self, category):
        """カテゴリに基づいて応答戦略を決定する"""
        if category == "挨拶":
            return "generate_greeting_response"
        elif category == "質問":
            return "generate_question_response"
        elif category == "指示":
            return "generate_instruction_response"
        elif category == "会話":
            return "generate_conversational_response"
        else:
            return "generate_default_response"