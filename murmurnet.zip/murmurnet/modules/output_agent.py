from llama_cpp import Llama
import os
import re

class OutputAgent:
    def __init__(self, config):
        self.config = config
        chat_template = config.get('chat_template')
        model_path = config.get('model_path', os.path.abspath(os.path.join(os.path.dirname(__file__), '../../models/gemma-3-1b-it-q4_0.gguf')))
        rag_db_path = config.get('rag_db_path')
        llama_kwargs = dict(
            model_path=model_path,
            n_ctx=32768,  # Context size updated to maximum supported by gemma3:1b
            n_threads=6,
            use_mmap=True,
            use_mlock=False,
            n_gpu_layers=0,
            seed=42,
            chat_format="gemma"
        )
        if chat_template:
            llama_kwargs['chat_template'] = chat_template
        self.llm = Llama(**llama_kwargs)
        self.rag_db_path = rag_db_path

    def generate(self, blackboard):
               # 1ターン分のみの明示的プロンプト構成
        user_input = blackboard.read('input')
        if isinstance(user_input, dict):
             user_input = user_input.get('normalized', str(user_input))
        rag_info = blackboard.read('rag')
         # 入力言語を自動判定し、system promptで指示
        def detect_lang(text):
             if re.search(r'[\u3040-\u30ff\u4e00-\u9fff]', text):
                 return 'ja'
             elif re.search(r'[a-zA-Z]', text):
                 return 'en'
             else:
                 return 'ja'
        lang = detect_lang(user_input)
        if lang == 'ja':
             system_prompt = "あなたはユーザーの入力言語（日本語または英語）に合わせて、同じ言語で丁寧に返答する多言語アシスタントです。必ず日本語で返答してください。"
        else:
             system_prompt = "You are a general-purpose AI assistant. Answer user questions from the perspective of an AI assistant. The following is a comprehensive list of opinions on the content. Please use it for reference only."
        prompt = f"{system_prompt}\n\n問い: {user_input}\n参考情報: {rag_info}\n\n答え:"

        messages = [
            {"role": "user", "content": prompt}
        ]

        # max_tokensの増加
        response = self.llm.create_chat_completion(messages=messages, max_tokens=1024, temperature=0.7)  # Adjusted temperature for more deterministic output
        answer = response["choices"][0]["message"]["content"].strip()

        # 応答の完全性チェック機能の追加
        def check_response_completeness(text):
            # 文が途中で切れていないか確認
            if text.endswith(('。', '！', '？', '」', '）', ')', '.', '!', '?', '"')):
                return True
            return False

        # 応答生成後
        if not check_response_completeness(answer):
            # 応答が不完全な場合、続きを生成
            continuation_prompt = f"以下の文章の続きを短く完結させてください（日本語で）：\n{answer}"
            continuation_messages = [{"role": "user", "content": continuation_prompt}]
            continuation_response = self.llm.create_chat_completion(messages=continuation_messages, max_tokens=512)
            continuation = continuation_response["choices"][0]["message"]["content"].strip()
            answer = answer + continuation

        return answer
